package com.flamehaus.controller;

import com.flamehaus.entity.MenuItem;
import com.flamehaus.service.MenuItemService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/menu")
public class MenuItemController {

    private final MenuItemService menuItemService;

    public MenuItemController(MenuItemService menuItemService) {
        this.menuItemService = menuItemService;
    }

    // Public — used by website
    @GetMapping
    public ResponseEntity<List<MenuItem>> getAll(@RequestParam(required = false) Boolean availableOnly) {
        if (Boolean.TRUE.equals(availableOnly)) {
            return ResponseEntity.ok(menuItemService.getAvailable());
        }
        return ResponseEntity.ok(menuItemService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MenuItem> getById(@PathVariable Long id) {
        return ResponseEntity.ok(menuItemService.getById(id));
    }

    // Protected — admin only
    @PostMapping
    public ResponseEntity<MenuItem> create(@Valid @RequestBody MenuItem item) {
        return ResponseEntity.ok(menuItemService.create(item));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MenuItem> update(@PathVariable Long id, @Valid @RequestBody MenuItem item) {
        return ResponseEntity.ok(menuItemService.update(id, item));
    }

    @PatchMapping("/{id}/toggle")
    public ResponseEntity<MenuItem> toggleAvailability(@PathVariable Long id) {
        return ResponseEntity.ok(menuItemService.toggleAvailability(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long id) {
        menuItemService.delete(id);
        return ResponseEntity.ok(Map.of("message", "Menu item deleted successfully"));
    }
}

package com.flamehaus.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class OrderRequest {

    @NotBlank
    private String customerName;
    private String customerPhone;
    private String deliveryAddress;

    @NotNull
    private Double total;

    private String itemsSummary;

    /** Optional: lat/lng sent from frontend (browser Geolocation or entered address) */
    private Double deliveryLat;
    private Double deliveryLng;

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String n) { this.customerName = n; }
    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String p) { this.customerPhone = p; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String a) { this.deliveryAddress = a; }
    public Double getTotal() { return total; }
    public void setTotal(Double t) { this.total = t; }
    public String getItemsSummary() { return itemsSummary; }
    public void setItemsSummary(String s) { this.itemsSummary = s; }
    public Double getDeliveryLat() { return deliveryLat; }
    public void setDeliveryLat(Double lat) { this.deliveryLat = lat; }
    public Double getDeliveryLng() { return deliveryLng; }
    public void setDeliveryLng(Double lng) { this.deliveryLng = lng; }
}

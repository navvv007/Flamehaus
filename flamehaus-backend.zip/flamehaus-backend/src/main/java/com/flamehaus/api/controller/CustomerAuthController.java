package com.flamehaus.api.controller;

import com.flamehaus.api.dto.*;
import com.flamehaus.api.entity.Customer;
import com.flamehaus.api.repository.CustomerRepository;
import com.flamehaus.api.security.JwtUtil;
import com.flamehaus.api.security.OtpStore;
import com.flamehaus.api.security.TokenBlacklistService;
import com.flamehaus.api.service.CustomerAuthService;
import com.flamehaus.api.service.SmsService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/customer")
public class CustomerAuthController {

    private final CustomerAuthService   customerAuthService;
    private final CustomerRepository    customerRepo;
    private final JwtUtil               jwtUtil;
    private final TokenBlacklistService blacklistService;
    private final OtpStore              otpStore;
    private final SmsService            smsService;

    public CustomerAuthController(CustomerAuthService customerAuthService,
                                   CustomerRepository customerRepo,
                                   JwtUtil jwtUtil,
                                   TokenBlacklistService blacklistService,
                                   OtpStore otpStore,
                                   SmsService smsService) {
        this.customerAuthService = customerAuthService;
        this.customerRepo        = customerRepo;
        this.jwtUtil             = jwtUtil;
        this.blacklistService    = blacklistService;
        this.otpStore            = otpStore;
        this.smsService          = smsService;
    }

    // ── Password login ────────────────────────────────────────────────────────

    @PostMapping("/auth/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest req) {
        try { return ResponseEntity.ok(customerAuthService.register(req)); }
        catch (RuntimeException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/auth/login")
    public ResponseEntity<?> login(@Valid @RequestBody CustomerLoginRequest req) {
        try { return ResponseEntity.ok(customerAuthService.login(req)); }
        catch (RuntimeException e) { return ResponseEntity.status(401).body(Map.of("error", e.getMessage())); }
    }

    // ── OTP login ─────────────────────────────────────────────────────────────

    /**
     * Step 1 — Request OTP.
     * Identifier = registered phone number (10-digit or +91XXXXXXXXXX).
     * OTP sent via SMS. Returns 200 even if phone not found (security: no enumeration).
     */
    @PostMapping("/auth/otp/send")
    public ResponseEntity<?> sendOtp(@Valid @RequestBody OtpRequest req) {
        String phone = req.getIdentifier();
        String normalised = normalisePhone(phone);

        // Look up customer by phone
        Customer customer = customerRepo.findByPhone(normalised)
                .or(() -> customerRepo.findByPhone(phone))
                .orElse(null);

        if (customer == null) {
            // Don't reveal that the phone isn't registered
            return ResponseEntity.ok(Map.of("message", "OTP sent if the number is registered"));
        }

        String otp = otpStore.generate(normalised);
        smsService.sendOtp(normalised, otp, customer.getName());

        return ResponseEntity.ok(Map.of(
            "message", "OTP sent to " + maskPhone(normalised),
            "maskedPhone", maskPhone(normalised)
        ));
    }

    /**
     * Step 2 — Verify OTP and return JWT.
     */
    @PostMapping("/auth/otp/verify")
    public ResponseEntity<?> verifyOtp(@Valid @RequestBody OtpVerifyRequest req) {
        String phone     = req.getIdentifier();
        String normalised = normalisePhone(phone);

        if (!otpStore.verify(normalised, req.getOtp())) {
            return ResponseEntity.status(401)
                    .body(Map.of("error", "Invalid or expired OTP. Please try again."));
        }

        Customer customer = customerRepo.findByPhone(normalised)
                .or(() -> customerRepo.findByPhone(phone))
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        String token = jwtUtil.generateCustomerToken(customer.getEmail(), customer.getId());
        return ResponseEntity.ok(new CustomerResponse(
            customer.getId(), customer.getName(), customer.getEmail(), customer.getPhone(), token
        ));
    }

    // ── Logout ────────────────────────────────────────────────────────────────

    @PostMapping("/auth/logout")
    public ResponseEntity<?> logout(Authentication auth) {
        if (auth != null && auth.getCredentials() instanceof String token) {
            blacklistService.blacklist(token, jwtUtil.extractExpiryMs(token));
        }
        return ResponseEntity.ok(Map.of("message", "Logged out successfully"));
    }

    // ── Profile ───────────────────────────────────────────────────────────────

    @GetMapping("/me")
    public ResponseEntity<?> me(Authentication auth) {
        try {
            var c = customerAuthService.getByEmail(auth.getName());
            return ResponseEntity.ok(Map.of(
                "id",    c.getId(),
                "name",  c.getName(),
                "email", c.getEmail(),
                "phone", c.getPhone() != null ? c.getPhone() : ""
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ── Util ─────────────────────────────────────────────────────────────────

    private String normalisePhone(String raw) {
        if (raw == null) return "";
        String digits = raw.replaceAll("[^0-9+]", "");
        if (digits.startsWith("+"))                            return digits;
        if (digits.length() == 10)                             return "+91" + digits;
        if (digits.length() == 12 && digits.startsWith("91")) return "+" + digits;
        return raw;
    }

    private String maskPhone(String phone) {
        if (phone == null || phone.length() < 4) return "****";
        return phone.substring(0, phone.length() - 4).replaceAll("[0-9]", "*")
             + phone.substring(phone.length() - 4);
    }
}

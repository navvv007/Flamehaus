package com.flamehaus.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlamehausApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(FlamehausApiApplication.class, args);
    }
}

package com.flamehaus.api.service;

import com.flamehaus.api.dto.*;
import com.flamehaus.api.entity.AdminUser;
import com.flamehaus.api.entity.PasswordResetToken;
import com.flamehaus.api.repository.AdminUserRepository;
import com.flamehaus.api.repository.PasswordResetTokenRepository;
import com.flamehaus.api.security.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class AuthService {

    private final AdminUserRepository adminRepo;
    private final PasswordResetTokenRepository resetTokenRepo;
    private final PasswordEncoder encoder;
    private final JwtUtil jwtUtil;
    private final SmsService smsService;

    public AuthService(AdminUserRepository adminRepo, PasswordResetTokenRepository resetTokenRepo,
                       PasswordEncoder encoder, JwtUtil jwtUtil, SmsService smsService) {
        this.adminRepo = adminRepo;
        this.resetTokenRepo = resetTokenRepo;
        this.encoder = encoder;
        this.jwtUtil = jwtUtil;
        this.smsService = smsService;
    }

    public LoginResponse login(LoginRequest req) {
        AdminUser user = adminRepo.findByUsername(req.getUsername())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));
        if (!user.getActive()) throw new RuntimeException("Account is disabled");
        if (!encoder.matches(req.getPassword(), user.getPassword()))
            throw new RuntimeException("Invalid credentials");

        String token = jwtUtil.generateAdminToken(user.getUsername(), user.getRole().name());
        return new LoginResponse(token, user.getUsername(), user.getRole().name(), user.getDisplayName());
    }

    /** Returns a reset token (in real app you'd email this) */
    public String forgotPassword(String username) {
        AdminUser user = adminRepo.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Username not found"));
        // Invalidate old tokens
        resetTokenRepo.deleteAllByUsername(username);
        // Create new 15-min token
        String raw = UUID.randomUUID().toString().replace("-", "").substring(0, 32);
        resetTokenRepo.save(new PasswordResetToken(raw, username, LocalDateTime.now().plusMinutes(15)));
        // SMS: send reset token to admin's phone (if stored)
        // Note: AdminUser doesn't store phone — add phone field to AdminUser entity for production.
        // For now, the token is returned in the response for dev/testing.
        return raw;
    }

    public void resetPassword(ResetPasswordRequest req) {
        PasswordResetToken prt = resetTokenRepo.findByToken(req.getToken())
                .orElseThrow(() -> new RuntimeException("Invalid or expired token"));
        if (prt.getUsed() || prt.isExpired()) throw new RuntimeException("Token expired");
        AdminUser user = adminRepo.findByUsername(prt.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setPassword(encoder.encode(req.getNewPassword()));
        adminRepo.save(user);
        prt.setUsed(true);
        resetTokenRepo.save(prt);
    }

    public void changePassword(String username, ChangePasswordRequest req) {
        AdminUser user = adminRepo.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        if (!encoder.matches(req.getCurrentPassword(), user.getPassword()))
            throw new RuntimeException("Current password is incorrect");
        user.setPassword(encoder.encode(req.getNewPassword()));
        adminRepo.save(user);
    }

    // ── Admin user management (SUPERADMIN only) ───────────────────────────────

    public List<AdminUser> listAdmins() { return adminRepo.findAll(); }

    public AdminUser createAdmin(AdminUserRequest req) {
        if (adminRepo.existsByUsername(req.getUsername()))
            throw new RuntimeException("Username already exists");
        AdminUser.Role role = AdminUser.Role.valueOf(req.getRole().toUpperCase());
        AdminUser u = new AdminUser(req.getUsername(), encoder.encode(req.getPassword()), role, req.getDisplayName());
        return adminRepo.save(u);
    }

    public void toggleAdmin(Long id) {
        AdminUser u = adminRepo.findById(id).orElseThrow(() -> new RuntimeException("Not found"));
        u.setActive(!u.getActive());
        adminRepo.save(u);
    }

    public void deleteAdmin(Long id) { adminRepo.deleteById(id); }
}

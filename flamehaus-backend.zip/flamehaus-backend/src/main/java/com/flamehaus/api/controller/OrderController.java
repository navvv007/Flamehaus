package com.flamehaus.api.controller;

import com.flamehaus.api.dto.DashboardStats;
import com.flamehaus.api.dto.OrderRequest;
import com.flamehaus.api.entity.Order;
import com.flamehaus.api.security.JwtUtil;
import com.flamehaus.api.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class OrderController {

    private final OrderService orderService;
    private final JwtUtil      jwtUtil;

    public OrderController(OrderService orderService, JwtUtil jwtUtil) {
        this.orderService = orderService;
        this.jwtUtil      = jwtUtil;
    }

    // ── Public ────────────────────────────────────────────────────────────────

    /** Place order — optionally links to logged-in customer */
    @PostMapping("/orders")
    public ResponseEntity<Order> place(@Valid @RequestBody OrderRequest req, Authentication auth) {
        String customerEmail = null;
        if (auth != null && auth.getCredentials() instanceof String token) {
            if ("CUSTOMER".equals(jwtUtil.extractType(token))) {
                customerEmail = auth.getName();
            }
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(orderService.placeOrder(req, customerEmail));
    }

    /** Public tracking endpoint — anyone with the order ID can poll status */
    @GetMapping("/orders/{id}/track")
    public ResponseEntity<?> track(@PathVariable Long id) {
        try { return ResponseEntity.ok(orderService.getById(id)); }
        catch (RuntimeException e) { return ResponseEntity.notFound().build(); }
    }

    // ── Customer (JWT required) ───────────────────────────────────────────────

    /**
     * Customer: list all their own orders.
     * FIX: moved here from CustomerAuthController to avoid URL ambiguity with
     * /customer/orders/{id} — Spring was matching GET /customer/orders to the
     * wrong handler when both patterns existed in different controllers.
     */
    @GetMapping("/customer/orders")
    public ResponseEntity<?> myOrders(Authentication auth) {
        try {
            if (auth == null || !(auth.getCredentials() instanceof String token)) {
                return ResponseEntity.status(401).body(Map.of("error", "Unauthorized"));
            }
            Long customerId = jwtUtil.extractCustomerId(token);
            if (customerId == null) {
                return ResponseEntity.status(401).body(Map.of("error", "Invalid customer token"));
            }
            return ResponseEntity.ok(orderService.getByCustomerId(customerId));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** Customer: single order detail — only if it belongs to them */
    @GetMapping("/customer/orders/{id}")
    public ResponseEntity<?> customerOrderDetail(@PathVariable Long id, Authentication auth) {
        try {
            if (auth == null || !(auth.getCredentials() instanceof String token)) {
                return ResponseEntity.status(401).body(Map.of("error", "Unauthorized"));
            }
            Long customerId = jwtUtil.extractCustomerId(token);
            if (customerId == null) {
                return ResponseEntity.status(401).body(Map.of("error", "Invalid customer token"));
            }
            return ResponseEntity.ok(orderService.getByIdForCustomer(id, customerId));
        } catch (RuntimeException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        }
    }

    // ── Admin ─────────────────────────────────────────────────────────────────

    @GetMapping("/admin/orders")
    public List<Order> getAll() { return orderService.getAll(); }

    @GetMapping("/admin/orders/{id}")
    public ResponseEntity<?> adminOrderDetail(@PathVariable Long id) {
        try { return ResponseEntity.ok(orderService.getById(id)); }
        catch (RuntimeException e) { return ResponseEntity.notFound().build(); }
    }

    @PatchMapping("/admin/orders/{id}/advance")
    public ResponseEntity<?> advance(@PathVariable Long id) {
        try { return ResponseEntity.ok(orderService.advanceStatus(id)); }
        catch (RuntimeException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @GetMapping("/admin/dashboard/stats")
    public DashboardStats stats() { return orderService.getStats(); }
}

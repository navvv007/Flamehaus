package com.flamehaus.api.controller;

import com.flamehaus.api.dto.RatingRequest;
import com.flamehaus.api.entity.DishRating;
import com.flamehaus.api.entity.OrderRating;
import com.flamehaus.api.security.JwtUtil;
import com.flamehaus.api.service.RatingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class RatingController {

    private final RatingService ratingService;
    private final JwtUtil       jwtUtil;

    public RatingController(RatingService ratingService, JwtUtil jwtUtil) {
        this.ratingService = ratingService;
        this.jwtUtil       = jwtUtil;
    }

    // ── Customer endpoints ────────────────────────────────────────────────────

    /**
     * Submit rating for a delivered order (overall + dish ratings).
     * Requires customer JWT.
     */
    @PostMapping("/customer/ratings")
    public ResponseEntity<?> submit(@Valid @RequestBody RatingRequest req, Authentication auth) {
        try {
            String token    = (String) auth.getCredentials();
            Long customerId = jwtUtil.extractCustomerId(token);
            if (customerId == null) {
                return ResponseEntity.status(401).body(Map.of("error", "Invalid token"));
            }
            return ResponseEntity.ok(ratingService.submitRating(req, customerId));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** Check if customer has already rated an order. */
    @GetMapping("/customer/ratings/order/{orderId}/check")
    public ResponseEntity<?> check(@PathVariable Long orderId) {
        return ResponseEntity.ok(Map.of("hasRated", ratingService.hasRated(orderId)));
    }

    /** Get ratings for a specific order (for display in order detail). */
    @GetMapping("/customer/ratings/order/{orderId}")
    public ResponseEntity<?> getOrderRatings(@PathVariable Long orderId) {
        OrderRating  or = ratingService.getOrderRating(orderId);
        List<DishRating> dr = ratingService.getDishRatings(orderId);
        return ResponseEntity.ok(Map.of(
            "orderRating", or  != null ? or : Map.of(),
            "dishRatings", dr
        ));
    }

    // ── Public endpoints ──────────────────────────────────────────────────────

    /** Public — get aggregate ratings for a menu item (shown on menu cards). */
    @GetMapping("/menu/{menuItemId}/ratings")
    public ResponseEntity<?> menuItemRatings(@PathVariable Long menuItemId) {
        return ResponseEntity.ok(ratingService.getMenuItemRatings(menuItemId));
    }

    // ── Admin endpoints ───────────────────────────────────────────────────────

    /** Admin — all order ratings overview. */
    @GetMapping("/admin/ratings")
    public ResponseEntity<?> allRatings() {
        List<OrderRating> ratings = ratingService.getAllOrderRatings();
        return ResponseEntity.ok(ratings);
    }
}

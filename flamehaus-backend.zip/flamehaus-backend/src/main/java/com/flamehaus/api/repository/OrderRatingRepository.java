package com.flamehaus.api.repository;

import com.flamehaus.api.entity.OrderRating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface OrderRatingRepository extends JpaRepository<OrderRating, Long> {
    Optional<OrderRating> findByOrderId(Long orderId);
    boolean existsByOrderId(Long orderId);
    List<OrderRating> findAllByOrderByCreatedAtDesc();

    @Query("SELECT AVG(r.stars) FROM OrderRating r")
    Double avgStars();
}

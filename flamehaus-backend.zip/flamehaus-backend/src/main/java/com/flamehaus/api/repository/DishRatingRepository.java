package com.flamehaus.api.repository;

import com.flamehaus.api.entity.DishRating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface DishRatingRepository extends JpaRepository<DishRating, Long> {
    List<DishRating> findByMenuItemId(Long menuItemId);
    List<DishRating> findByOrderId(Long orderId);
    boolean existsByOrderIdAndMenuItemIdAndCustomerId(Long orderId, Long menuItemId, Long customerId);

    @Query("SELECT AVG(r.stars) FROM DishRating r WHERE r.menuItem.id = :menuItemId")
    Double avgStarsByMenuItem(@Param("menuItemId") Long menuItemId);

    @Query("SELECT COUNT(r) FROM DishRating r WHERE r.menuItem.id = :menuItemId")
    Long countByMenuItem(@Param("menuItemId") Long menuItemId);
}

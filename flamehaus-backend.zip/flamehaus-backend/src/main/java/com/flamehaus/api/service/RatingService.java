package com.flamehaus.api.service;

import com.flamehaus.api.dto.RatingRequest;
import com.flamehaus.api.entity.*;
import com.flamehaus.api.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class RatingService {

    private final OrderRepository      orderRepo;
    private final OrderRatingRepository orderRatingRepo;
    private final DishRatingRepository  dishRatingRepo;
    private final MenuItemRepository    menuItemRepo;
    private final CustomerRepository    customerRepo;

    public RatingService(OrderRepository orderRepo,
                         OrderRatingRepository orderRatingRepo,
                         DishRatingRepository dishRatingRepo,
                         MenuItemRepository menuItemRepo,
                         CustomerRepository customerRepo) {
        this.orderRepo      = orderRepo;
        this.orderRatingRepo = orderRatingRepo;
        this.dishRatingRepo  = dishRatingRepo;
        this.menuItemRepo    = menuItemRepo;
        this.customerRepo    = customerRepo;
    }

    @Transactional
    public Map<String, Object> submitRating(RatingRequest req, Long customerId) {
        Order order = orderRepo.findById(req.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found"));

        if (!"Delivered".equals(order.getStatus())) {
            throw new RuntimeException("Can only rate delivered orders");
        }

        Customer customer = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // ── Overall order rating ─────────────────────────────────────────────
        if (orderRatingRepo.existsByOrderId(order.getId())) {
            throw new RuntimeException("You have already rated this order");
        }

        OrderRating or = new OrderRating();
        or.setOrder(order);
        or.setCustomer(customer);
        or.setStars(req.getOrderStars());
        or.setComment(req.getOrderComment());
        orderRatingRepo.save(or);

        // ── Dish ratings ─────────────────────────────────────────────────────
        int dishesRated = 0;
        if (req.getDishRatings() != null) {
            for (RatingRequest.DishRatingItem item : req.getDishRatings()) {
                if (dishRatingRepo.existsByOrderIdAndMenuItemIdAndCustomerId(
                        order.getId(), item.getMenuItemId(), customerId)) {
                    continue; // skip duplicates silently
                }
                MenuItem menuItem = menuItemRepo.findById(item.getMenuItemId())
                        .orElse(null);
                if (menuItem == null) continue;

                DishRating dr = new DishRating();
                dr.setOrder(order);
                dr.setMenuItem(menuItem);
                dr.setCustomer(customer);
                dr.setStars(item.getStars());
                dr.setComment(item.getComment());
                dishRatingRepo.save(dr);

                // Update MenuItem aggregate rating
                Double avg   = dishRatingRepo.avgStarsByMenuItem(menuItem.getId());
                Long   count = dishRatingRepo.countByMenuItem(menuItem.getId());
                if (avg != null) {
                    menuItem.setRating(Math.round(avg * 10.0) / 10.0);
                    menuItem.setReviews(count.intValue());
                    menuItemRepo.save(menuItem);
                }
                dishesRated++;
            }
        }

        return Map.of(
            "success",     true,
            "orderRated",  true,
            "dishesRated", dishesRated,
            "message",     "Thank you for your rating!"
        );
    }

    public boolean hasRated(Long orderId) {
        return orderRatingRepo.existsByOrderId(orderId);
    }

    public OrderRating getOrderRating(Long orderId) {
        return orderRatingRepo.findByOrderId(orderId).orElse(null);
    }

    public List<DishRating> getDishRatings(Long orderId) {
        return dishRatingRepo.findByOrderId(orderId);
    }

    public List<OrderRating> getAllOrderRatings() {
        return orderRatingRepo.findAllByOrderByCreatedAtDesc();
    }

    public Map<String, Object> getMenuItemRatings(Long menuItemId) {
        Double avg   = dishRatingRepo.avgStarsByMenuItem(menuItemId);
        Long   count = dishRatingRepo.countByMenuItem(menuItemId);
        List<DishRating> recent = dishRatingRepo.findByMenuItemId(menuItemId);
        return Map.of(
            "menuItemId", menuItemId,
            "avgRating",  avg   != null ? Math.round(avg * 10.0) / 10.0 : 0.0,
            "totalCount", count != null ? count : 0L,
            "ratings",    recent
        );
    }
}

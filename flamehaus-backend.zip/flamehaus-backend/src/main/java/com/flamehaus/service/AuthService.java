package com.flamehaus.service;

import com.flamehaus.dto.LoginRequest;
import com.flamehaus.dto.LoginResponse;
import com.flamehaus.entity.Admin;
import com.flamehaus.repository.AdminRepository;
import com.flamehaus.security.AdminPrincipal;
import com.flamehaus.security.JwtUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final AdminRepository adminRepository;

    @Value("${app.jwt.expiration-ms}")
    private long expirationMs;

    public AuthService(AuthenticationManager authenticationManager, JwtUtil jwtUtil, AdminRepository adminRepository) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.adminRepository = adminRepository;
    }

    public LoginResponse login(LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );

            AdminPrincipal principal = (AdminPrincipal) authentication.getPrincipal();
            Admin admin = principal.getAdmin();

            admin.setLastLogin(LocalDateTime.now());
            adminRepository.save(admin);

            String token = jwtUtil.generateToken(admin.getUsername(), admin.getRole());

            return new LoginResponse(token, admin.getUsername(), admin.getEmail(), admin.getRole(), expirationMs);
        } catch (org.springframework.security.core.AuthenticationException ex) {
            throw new BadCredentialsException("Invalid username or password");
        }
    }
}

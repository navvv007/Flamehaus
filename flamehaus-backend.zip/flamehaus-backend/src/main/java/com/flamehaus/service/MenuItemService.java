package com.flamehaus.service;

import com.flamehaus.entity.MenuItem;
import com.flamehaus.exception.ResourceNotFoundException;
import com.flamehaus.repository.MenuItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuItemService {

    private final MenuItemRepository menuItemRepository;

    public MenuItemService(MenuItemRepository menuItemRepository) {
        this.menuItemRepository = menuItemRepository;
    }

    public List<MenuItem> getAll() {
        return menuItemRepository.findAll();
    }

    public List<MenuItem> getAvailable() {
        return menuItemRepository.findByAvailableTrue();
    }

    public MenuItem getById(Long id) {
        return menuItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Menu item not found with id: " + id));
    }

    public MenuItem create(MenuItem item) {
        return menuItemRepository.save(item);
    }

    public MenuItem update(Long id, MenuItem updated) {
        MenuItem existing = getById(id);
        existing.setName(updated.getName());
        existing.setCategory(updated.getCategory());
        existing.setPrice(updated.getPrice());
        existing.setDescription(updated.getDescription());
        existing.setImage(updated.getImage());
        existing.setBadge(updated.getBadge());
        existing.setAvailable(updated.isAvailable());
        if (updated.getPrepTime() != null) {
            existing.setPrepTime(updated.getPrepTime());
        }
        return menuItemRepository.save(existing);
    }

    public MenuItem toggleAvailability(Long id) {
        MenuItem item = getById(id);
        item.setAvailable(!item.isAvailable());
        return menuItemRepository.save(item);
    }

    public void delete(Long id) {
        MenuItem item = getById(id);
        menuItemRepository.delete(item);
    }
}

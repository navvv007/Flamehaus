package com.flamehaus.service;

import com.flamehaus.dto.OrderRequest;
import com.flamehaus.entity.Order;
import com.flamehaus.entity.OrderItem;
import com.flamehaus.exception.ResourceNotFoundException;
import com.flamehaus.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    private static final List<String> VALID_STATUSES = List.of("Pending", "Preparing", "On the Way", "Delivered");

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<Order> getAll() {
        return orderRepository.findAllByOrderByCreatedAtDesc();
    }

    public Order getById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + id));
    }

    @Transactional
    public Order placeOrder(OrderRequest request) {
        Order order = new Order();
        order.setCustomerName(request.getCustomerName());
        order.setCustomerPhone(request.getCustomerPhone());
        order.setDeliveryAddress(request.getDeliveryAddress());
        order.setTotal(request.getTotal());
        order.setStatus("Pending");

        for (OrderRequest.OrderItemRequest itemReq : request.getItems()) {
            OrderItem item = new OrderItem(order, itemReq.getMenuItemId(), itemReq.getItemName(),
                    itemReq.getPrice(), itemReq.getQuantity());
            order.getItems().add(item);
        }

        return orderRepository.save(order);
    }

    public Order updateStatus(Long id, String status) {
        if (!VALID_STATUSES.contains(status)) {
            throw new IllegalArgumentException("Invalid status: " + status);
        }
        Order order = getById(id);
        order.setStatus(status);
        return orderRepository.save(order);
    }

    public void delete(Long id) {
        Order order = getById(id);
        orderRepository.delete(order);
    }
}

package com.flamehaus.config;

import com.flamehaus.entity.Admin;
import com.flamehaus.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final AdminRepository adminRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.admin.default-username}")
    private String defaultUsername;

    @Value("${app.admin.default-password}")
    private String defaultPassword;

    @Value("${app.admin.default-email}")
    private String defaultEmail;

    public DataSeeder(AdminRepository adminRepository, PasswordEncoder passwordEncoder) {
        this.adminRepository = adminRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (!adminRepository.existsByUsername(defaultUsername)) {
            Admin admin = new Admin(
                    defaultUsername,
                    passwordEncoder.encode(defaultPassword),
                    defaultEmail,
                    "ADMIN"
            );
            adminRepository.save(admin);
            System.out.println("===========================================");
            System.out.println("Default admin created:");
            System.out.println("Username: " + defaultUsername);
            System.out.println("Password: " + defaultPassword);
            System.out.println("Change this password after first login!");
            System.out.println("===========================================");
        }
    }
}

import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { fetchAdminOrderDetail, advanceOrder } from "../../api/apiClient";
import DeliveryMap from "../../website/components/DeliveryMap";
import OrderTimeline from "../../website/components/OrderTimeline";
import AddressDisplay from "../../admin/pages/AddressDisplay";

const STATUS_COLOR = {
  Delivered:    { bg: "rgba(87,204,153,0.15)",  color: "#57CC99",  border: "rgba(87,204,153,0.3)" },
  Preparing:    { bg: "rgba(244,200,66,0.15)",  color: "#F4C842",  border: "rgba(244,200,66,0.3)" },
  "On the Way": { bg: "rgba(76,201,240,0.15)",  color: "#4CC9F0",  border: "rgba(76,201,240,0.3)" },
  Pending:      { bg: "rgba(255,107,53,0.15)",  color: "#FF6B35",  border: "rgba(255,107,53,0.3)" },
};

const NEXT = { Pending: "Preparing", Preparing: "On the Way", "On the Way": "Delivered" };

function fmt(dt) {
  if (!dt) return "—";
  return new Date(dt).toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function AdminOrderDetail() {
  const { id }                          = useParams();
  const [order, setOrder]               = useState(null);
  const [loading, setLoading]           = useState(true);
  const [advancing, setAdvancing]       = useState(false);
  const [error, setError]               = useState("");
  const [successMsg, setSuccessMsg]     = useState("");

  useEffect(() => {
    fetchAdminOrderDetail(id)
      .then((r) => setOrder(r.data))
      .catch(() => setError("Order not found"))
      .finally(() => setLoading(false));
  }, [id]);

  const handleAdvance = async () => {
    setAdvancing(true); setError(""); setSuccessMsg("");
    try {
      const res = await advanceOrder(order.id);
      setOrder(res.data);
      setSuccessMsg(`Status updated to: ${res.data.status}`);
      setTimeout(() => setSuccessMsg(""), 3000);
    } catch (e) {
      setError(e.response?.data?.error || "Failed to advance status");
    } finally {
      setAdvancing(false);
    }
  };

  if (loading) return (
    <div style={{ padding: 40, display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh" }}>
      <div style={{ color: "var(--muted)", textAlign: "center" }}>
        <div style={{ fontSize: "2rem", marginBottom: 12 }}>⏳</div>
        <p>Loading order…</p>
      </div>
    </div>
  );

  if (error && !order) return (
    <div style={{ padding: 40, textAlign: "center", minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div>
        <div style={{ fontSize: "3rem", marginBottom: 16 }}>📦</div>
        <p style={{ color: "var(--muted)", marginBottom: 24 }}>{error}</p>
        <Link to="/admin/orders" className="btn-outline">← Back to Orders</Link>
      </div>
    </div>
  );

  const sc      = STATUS_COLOR[order.status] || { bg: "#222", color: "#888", border: "#333" };
  const nextSt  = NEXT[order.status];
  const items   = (order.itemsSummary || "").split(",").map((s) => s.trim()).filter(Boolean);

  return (
    <div style={{ padding: "40px 36px" }}>
      {/* Back */}
      <Link to="/admin/orders" style={{ color: "var(--muted)", fontSize: "0.88rem", display: "inline-flex", alignItems: "center", gap: 6, marginBottom: 32 }}>
        ← All Orders
      </Link>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 16, marginBottom: 36 }}>
        <div>
          <div className="section-label" style={{ marginBottom: 8 }}>Order Management</div>
          <h1 style={{ fontFamily: "Syne, sans-serif", fontSize: "2rem", marginBottom: 6 }}>
            Order <span style={{ color: "var(--flame)" }}>#{order.id}</span>
          </h1>
          <p style={{ color: "var(--muted)", fontSize: "0.88rem" }}>Placed {fmt(order.createdAt)}</p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <span style={{ padding: "8px 20px", borderRadius: 30, fontSize: "0.88rem", fontWeight: 700,
            background: sc.bg, color: sc.color, border: `1px solid ${sc.border}` }}>
            {order.status}
          </span>
          {nextSt && (
            <button onClick={handleAdvance} disabled={advancing} className="btn-primary"
              style={{ opacity: advancing ? 0.7 : 1 }}>
              {advancing ? "Updating…" : `→ Mark as ${nextSt}`}
            </button>
          )}
        </div>
      </div>

      {/* Feedback */}
      {successMsg && (
        <div style={{ background: "rgba(87,204,153,0.1)", border: "1px solid rgba(87,204,153,0.3)", borderRadius: 10, padding: "12px 18px", marginBottom: 24, color: "#57CC99", fontSize: "0.88rem" }}>
          ✓ {successMsg}
        </div>
      )}
      {error && (
        <div style={{ background: "rgba(230,57,70,0.1)", border: "1px solid rgba(230,57,70,0.3)", borderRadius: 10, padding: "12px 18px", marginBottom: 24, color: "#E63946", fontSize: "0.88rem" }}>
          {error}
        </div>
      )}

      {/* Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 28, alignItems: "start" }}>

        {/* LEFT */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          {/* Map */}
          <DeliveryMap order={order} />

          {/* ETA */}
          {order.estimatedDelivery && order.status !== "Delivered" && (
            <div className="card" style={{ padding: "18px 22px", display: "flex", alignItems: "center", gap: 14,
              borderColor: "rgba(76,201,240,0.25)" }}>
              <span style={{ fontSize: "1.6rem" }}>⏱</span>
              <div>
                <p style={{ fontSize: "0.75rem", color: "var(--muted)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 1, marginBottom: 3 }}>Customer ETA</p>
                <p style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, color: "#4CC9F0" }}>
                  {fmt(order.estimatedDelivery)}
                </p>
              </div>
            </div>
          )}

          {/* Timeline */}
          <div className="card" style={{ padding: "28px" }}>
            <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1.1rem", marginBottom: 28 }}>Order Timeline</h3>
            <OrderTimeline status={order.status} trackingNote={order.trackingNote} />
          </div>
        </div>

        {/* RIGHT */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Customer info */}
          <div className="card" style={{ padding: "24px" }}>
            <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1rem", marginBottom: 18 }}>👤 Customer</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                ["Name",    order.customerName    || "—"],
                ["Phone",   order.customerPhone   || "—"],
                ["Account", order.customer ? `${order.customer.email} (ID: ${order.customer.id})` : "Guest Order"],
              ].map(([l, v]) => (
                <div key={l} style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                  <span style={{ fontSize: "0.72rem", fontWeight: 600, color: "var(--muted)", letterSpacing: 1, textTransform: "uppercase" }}>{l}</span>
                  <span style={{ fontSize: "0.87rem", lineHeight: 1.4, wordBreak: "break-word" }}>{v}</span>
                </div>
              ))}
              <AddressDisplay order={order} />
              <AddressDisplay order={order} compact />  
            </div>
          </div>

          {/* Items */}
          <div className="card" style={{ padding: "24px" }}>
            <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1rem", marginBottom: 18 }}>🧾 Items</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {items.map((item, i) => (
                <div key={i} style={{ padding: "9px 12px", background: "var(--charcoal)", borderRadius: 8, fontSize: "0.87rem", display: "flex", alignItems: "center", gap: 8 }}>
                  <span>🍽</span> {item}
                </div>
              ))}
            </div>
          </div>

          {/* Payment */}
          <div className="card" style={{ padding: "24px" }}>
            <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1rem", marginBottom: 18 }}>💳 Payment</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                ["Subtotal (USD)", `$${order.total.toFixed(2)}`],
                ["Subtotal (INR)", `₹${(order.total * 84).toFixed(0)}`],
              ].map(([l, v]) => (
                <div key={l} style={{ display: "flex", justifyContent: "space-between", fontSize: "0.87rem" }}>
                  <span style={{ color: "var(--muted)" }}>{l}</span>
                  <span style={{ fontWeight: 600 }}>{v}</span>
                </div>
              ))}
              <div style={{ borderTop: "1px solid var(--border)", paddingTop: 12, marginTop: 4,
                display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700 }}>Total</span>
                <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.3rem", color: "var(--flame)" }}>
                  ₹{(order.total * 84).toFixed(0)}
                </span>
              </div>
            </div>
          </div>

          {/* Timestamps */}
          <div className="card" style={{ padding: "24px" }}>
            <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1rem", marginBottom: 18 }}>🕒 Timestamps</h3>
            {[
              ["Created",   fmt(order.createdAt)],
              ["Updated",   fmt(order.updatedAt)],
              ["ETA",       order.status === "Delivered" ? "Delivered" : fmt(order.estimatedDelivery)],
            ].map(([l, v]) => (
              <div key={l} style={{ display: "flex", flexDirection: "column", gap: 3, marginBottom: 12 }}>
                <span style={{ fontSize: "0.72rem", fontWeight: 600, color: "var(--muted)", letterSpacing: 1, textTransform: "uppercase" }}>{l}</span>
                <span style={{ fontSize: "0.87rem" }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

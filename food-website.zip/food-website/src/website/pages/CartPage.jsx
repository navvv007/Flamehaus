import { useApp } from "../../context/AppContext";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { placeOrder } from "../../api/apiClient";
import { useAuth } from "../../context/AuthContext";

export default function CartPage() {
  const { cart, removeFromCart, updateQty, clearCart, cartTotal } = useApp();
  const { isCustomer, customer } = useAuth();
  const navigate = useNavigate();
  const [form, setForm]     = useState({
    name:    isCustomer ? customer?.name  || "" : "",
    phone:   isCustomer ? customer?.phone || "" : "",
    address: "",
  });
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  const handleOrder = async () => {
    if (!form.name || !form.phone || !form.address) {
      setError("Please fill in all delivery fields."); return;
    }
    setLoading(true); setError("");
    try {
      const itemsSummary = cart.map((i) => `${i.name} x${i.qty}`).join(", ");
      let deliveryLat = null, deliveryLng = null;
      try {
        const pos = await new Promise((res, rej) =>
          navigator.geolocation.getCurrentPosition(res, rej, { timeout: 4000 })
        );
        deliveryLat = pos.coords.latitude;
        deliveryLng = pos.coords.longitude;
      } catch (_) {}

      const res = await placeOrder({
        customerName:    form.name,
        customerPhone:   form.phone,
        deliveryAddress: form.address,
        total:           parseFloat(cartTotal.toFixed(2)),
        itemsSummary,
        deliveryLat,
        deliveryLng,
      });
      clearCart();
      // Redirect to payment page
      navigate(`/payment/${res.data.id}`);
    } catch (e) {
      setError("Order failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (cart.length === 0) return (
    <div style={{ minHeight: "70vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "60px 5%" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: "4rem", marginBottom: 20 }}>🛒</div>
        <h2 style={{ fontSize: "2rem", marginBottom: 12 }}>Your cart is empty</h2>
        <p style={{ color: "var(--muted)", marginBottom: 32 }}>Add some dishes to get started</p>
        <Link to="/menu" className="btn-primary">Browse Menu</Link>
      </div>
    </div>
  );

  const delivery = 49;
  const taxes    = Math.round(cartTotal * 84 * 0.05);
  const subtotal = Math.round(cartTotal * 84);
  const total    = subtotal + delivery + taxes;

  return (
    <div style={{ padding: "60px 5%" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <h1 style={{ fontSize: "2.4rem", marginBottom: 8 }}>Your Cart</h1>
        <p style={{ color: "var(--muted)", marginBottom: 40 }}>{cart.length} {cart.length === 1 ? "item" : "items"}</p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 32, alignItems: "start" }}>
          {/* Items */}
          <div>
            {cart.map((item) => (
              <div key={item.id} className="card fade-in" style={{ padding: "20px 22px", marginBottom: 16, display: "flex", alignItems: "center", gap: 20 }}>
                <div style={{ fontSize: "2.5rem", width: 60, height: 60, background: "var(--charcoal)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  {item.image}
                </div>
                <div style={{ flex: 1 }}>
                  <h4 style={{ fontFamily: "Syne, sans-serif", marginBottom: 4 }}>{item.name}</h4>
                  <p style={{ color: "var(--muted)", fontSize: "0.85rem" }}>{item.category}</p>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <button onClick={() => updateQty(item.id, -1)} style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--border)", color: "#fff", fontWeight: 700, fontSize: "1rem", display: "flex", alignItems: "center", justifyContent: "center" }}>−</button>
                  <span style={{ fontWeight: 600, minWidth: 20, textAlign: "center" }}>{item.qty}</span>
                  <button onClick={() => updateQty(item.id, 1)} style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--flame)", color: "#fff", fontWeight: 700, fontSize: "1rem", display: "flex", alignItems: "center", justifyContent: "center" }}>+</button>
                </div>
                <div style={{ minWidth: 80, textAlign: "right" }}>
                  <p style={{ fontWeight: 700, color: "var(--flame)" }}>₹{(item.price * item.qty * 84).toFixed(0)}</p>
                  <p style={{ color: "var(--muted)", fontSize: "0.78rem" }}>₹{(item.price * 84).toFixed(0)} each</p>
                </div>
                <button onClick={() => removeFromCart(item.id)} style={{ background: "transparent", color: "var(--muted)", fontSize: "1.2rem", padding: "4px 8px" }}>✕</button>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="card" style={{ padding: 28, position: "sticky", top: 90 }}>
            <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1.3rem", marginBottom: 24 }}>Order Summary</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 20 }}>
              {[["Subtotal", `₹${subtotal}`], ["Delivery", `₹${delivery}`], ["GST (5%)", `₹${taxes}`]].map(([lbl, val]) => (
                <div key={lbl} style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "var(--muted)", fontSize: "0.9rem" }}>{lbl}</span>
                  <span style={{ fontSize: "0.9rem" }}>{val}</span>
                </div>
              ))}
            </div>
            <div style={{ borderTop: "1px solid var(--border)", paddingTop: 16, marginBottom: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700 }}>Total</span>
                <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.4rem", color: "var(--flame)" }}>₹{total}</span>
              </div>
            </div>
            <div style={{ marginBottom: 20, display: "flex", flexDirection: "column", gap: 10 }}>
              <input type="text" placeholder="Your name *" value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} style={{ width: "100%" }} />
              <input type="text" placeholder="Phone number *" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} style={{ width: "100%" }} />
              <input type="text" placeholder="Delivery address *" value={form.address} onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))} style={{ width: "100%" }} />
            </div>
            {error && <p style={{ color: "#E63946", fontSize: "0.85rem", marginBottom: 12, textAlign: "center" }}>{error}</p>}
            <button className="btn-primary" style={{ width: "100%", justifyContent: "center", padding: "14px 0", fontSize: "1rem", opacity: loading ? 0.7 : 1 }} onClick={handleOrder} disabled={loading}>
              {loading ? "Placing order…" : "🔥 Proceed to Payment"}
            </button>
            <button onClick={clearCart} style={{ width: "100%", marginTop: 10, background: "transparent", color: "var(--muted)", fontSize: "0.85rem", padding: "10px 0" }}>
              Clear Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

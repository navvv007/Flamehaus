import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { fetchMyOrders } from "../../api/apiClient";

const STATUS_COLOR = {
  Delivered:    { bg: "rgba(87,204,153,0.15)", color: "#57CC99" },
  Preparing:    { bg: "rgba(244,200,66,0.15)", color: "#F4C842" },
  "On the Way": { bg: "rgba(76,201,240,0.15)", color: "#4CC9F0" },
  Pending:      { bg: "rgba(255,107,53,0.15)", color: "#FF6B35" },
};

function fmt(dt) {
  if (!dt) return "—";
  const d = new Date(dt);
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })
       + " · " + d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}

export default function MyOrders() {
  // ✅ Fix: use customer + customerSignOut — matches AuthContext exports
  const { customer, customerSignOut, isCustomer } = useAuth();
  const navigate = useNavigate();

  const [orders,  setOrders]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState("");
  const [tab,     setTab]     = useState("orders");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isCustomer) {
      navigate("/login", { replace: true });
    }
  }, [isCustomer, navigate]);

  useEffect(() => {
    if (!isCustomer) return;
    setLoading(true);
    fetchMyOrders()
      .then((r) => {
        setOrders(r.data);
        setError("");
      })
      .catch((e) => {
        const msg = e.response?.data?.error || e.message || "Failed to load orders.";
        setError(msg);
      })
      .finally(() => setLoading(false));
  }, [isCustomer]);

  const handleSignOut = async () => {
    await customerSignOut();
    navigate("/");
  };

  if (!isCustomer) return null; // redirecting

  const totalSpent = orders.reduce((s, o) => s + o.total * 84, 0);
  const active     = orders.filter((o) => o.status !== "Delivered");

  return (
    <div style={{ padding: "60px 5%", maxWidth: 920, margin: "0 auto" }}>

      {/* Profile header */}
      <div style={{ display: "flex", alignItems: "center", gap: 24, marginBottom: 48, flexWrap: "wrap" }}>
        <div style={{
          width: 72, height: 72, borderRadius: "50%", background: "var(--flame)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.8rem", flexShrink: 0,
        }}>
          {customer?.name?.[0]?.toUpperCase() || "U"}
        </div>
        <div style={{ flex: 1 }}>
          <h1 style={{ fontFamily: "Syne,sans-serif", fontSize: "1.8rem", marginBottom: 4 }}>{customer?.name}</h1>
          <p style={{ color: "var(--muted)", fontSize: "0.9rem" }}>{customer?.email}</p>
        </div>
        <button onClick={handleSignOut} style={{
          padding: "9px 20px", borderRadius: 50, border: "1.5px solid var(--border)",
          color: "var(--muted)", fontSize: "0.85rem", background: "transparent", transition: "all 0.2s",
        }}
          onMouseEnter={(e) => { e.currentTarget.style.color = "#E63946"; e.currentTarget.style.borderColor = "rgba(230,57,70,0.4)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.color = "var(--muted)"; e.currentTarget.style.borderColor = "var(--border)"; }}>
          Sign Out
        </button>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 40 }}>
        {[
          ["📦", orders.length,                                        "Total Orders"],
          ["🔄", active.length,                                        "Active"],
          ["✅", orders.filter((o) => o.status === "Delivered").length, "Delivered"],
          ["💰", `₹${totalSpent.toFixed(0)}`,                          "Total Spent"],
        ].map(([icon, val, lbl]) => (
          <div key={lbl} className="card" style={{ padding: "18px 16px", textAlign: "center" }}>
            <div style={{ fontSize: "1.2rem", marginBottom: 6 }}>{icon}</div>
            <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.4rem", color: "var(--flame)", marginBottom: 2 }}>{val}</div>
            <div style={{ color: "var(--muted)", fontSize: "0.78rem" }}>{lbl}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 28 }}>
        {[["orders", "🧾 My Orders"], ["profile", "👤 Profile"]].map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)} style={{
            padding: "9px 22px", borderRadius: 50, fontWeight: 600, fontSize: "0.85rem", transition: "all 0.2s",
            background: tab === t ? "var(--flame)" : "var(--card)",
            color:      tab === t ? "#fff" : "var(--muted)",
            border:     `1.5px solid ${tab === t ? "var(--flame)" : "var(--border)"}`,
          }}>{label}</button>
        ))}
      </div>

      {/* Orders tab */}
      {tab === "orders" && (
        <>
          {/* Error banner */}
          {error && (
            <div style={{
              background: "rgba(230,57,70,0.1)", border: "1px solid rgba(230,57,70,0.3)",
              borderRadius: 12, padding: "14px 18px", marginBottom: 24,
              color: "#E63946", fontSize: "0.88rem", display: "flex", alignItems: "center", gap: 10,
            }}>
              <span>⚠️</span>
              <span>{error}</span>
              <button onClick={() => { setError(""); setLoading(true); fetchMyOrders().then((r) => setOrders(r.data)).catch((e) => setError(e.response?.data?.error || e.message)).finally(() => setLoading(false)); }}
                style={{ marginLeft: "auto", background: "transparent", color: "#E63946", fontSize: "0.82rem", textDecoration: "underline" }}>
                Retry
              </button>
            </div>
          )}

          {loading ? (
            <div style={{ textAlign: "center", padding: "60px 0", color: "var(--muted)" }}>
              <div style={{ fontSize: "2rem", marginBottom: 12 }}>⏳</div>
              <p>Loading your orders…</p>
            </div>
          ) : orders.length === 0 ? (
            <div style={{ textAlign: "center", padding: "80px 0" }}>
              <div style={{ fontSize: "3rem", marginBottom: 16 }}>🍽</div>
              <p style={{ color: "var(--muted)", fontSize: "1rem", marginBottom: 24 }}>You haven't ordered yet!</p>
              <Link to="/menu" className="btn-primary">Browse Menu</Link>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {orders.map((order) => {
                const sc     = STATUS_COLOR[order.status] || { bg: "#222", color: "#888" };
                const isLive = ["Pending", "Preparing", "On the Way"].includes(order.status);
                return (
                  <div key={order.id} className="card" style={{ padding: "22px 24px", transition: "box-shadow 0.2s" }}
                    onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 8px 30px rgba(255,107,53,0.1)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14, flexWrap: "wrap", gap: 12 }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                          <span style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, color: "var(--flame)" }}>#{order.id}</span>
                          <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: "0.72rem", fontWeight: 600, background: sc.bg, color: sc.color }}>
                            {order.status}
                          </span>
                          {isLive && (
                            <span style={{ fontSize: "0.68rem", color: "#57CC99", display: "flex", alignItems: "center", gap: 4 }}>
                              <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#57CC99", animation: "livePulse 1.5s infinite", display: "inline-block" }} />
                              Live
                            </span>
                          )}
                        </div>
                        <p style={{ color: "var(--muted)", fontSize: "0.82rem" }}>{fmt(order.createdAt)}</p>
                      </div>
                      <p style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.2rem", color: "var(--flame)" }}>
                        ₹{(order.total * 84).toFixed(0)}
                      </p>
                    </div>

                    <div style={{ borderTop: "1px solid var(--border)", paddingTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
                      <div>
                        <p style={{ color: "var(--muted)", fontSize: "0.82rem", marginBottom: 4 }}>📍 {order.deliveryAddress || "—"}</p>
                        <p style={{ color: "var(--white)", fontSize: "0.83rem", lineHeight: 1.5 }}>{order.itemsSummary || "—"}</p>
                      </div>
                      <Link to={`/orders/${order.id}`} style={{
                        padding: "8px 18px", borderRadius: 30, fontSize: "0.82rem", fontWeight: 600,
                        background: isLive ? "var(--flame)" : "var(--charcoal)",
                        color:      isLive ? "#fff" : "var(--muted)",
                        border:     `1.5px solid ${isLive ? "var(--flame)" : "var(--border)"}`,
                        whiteSpace: "nowrap", transition: "all 0.2s",
                      }}>
                        {isLive ? "🛵 Track" : "View Details"} →
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Profile tab */}
      {tab === "profile" && (
        <div className="card" style={{ padding: "28px 32px" }}>
          <h3 style={{ fontFamily: "Syne,sans-serif", marginBottom: 24 }}>Account Details</h3>
          {[["Full Name", customer?.name || "—"], ["Email", customer?.email || "—"], ["Phone", customer?.phone || "Not set"]].map(([l, v]) => (
            <div key={l} style={{ display: "flex", borderBottom: "1px solid var(--border)", paddingBottom: 14, marginBottom: 14 }}>
              <span style={{ minWidth: 120, color: "var(--muted)", fontSize: "0.88rem" }}>{l}</span>
              <span style={{ fontSize: "0.88rem" }}>{v}</span>
            </div>
          ))}
          <p style={{ color: "var(--muted)", fontSize: "0.82rem", marginTop: 16 }}>To update details, contact hello@flamehaus.in</p>
        </div>
      )}

      <style>{`
        @keyframes livePulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
      `}</style>
    </div>
  );
}

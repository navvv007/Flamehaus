import { createContext, useContext, useState } from "react";
import { adminLogin, adminLogout, customerLogin, customerLogout, customerRegister } from "../api/apiClient";

const AuthContext = createContext();

const load = (key) => { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } };

export function AuthProvider({ children }) {
  const [adminUser, setAdminUser] = useState(() => load("fh_admin_user"));
  const [customer,  setCustomer]  = useState(() => load("fh_customer"));

  // ── Admin ──────────────────────────────────────────────────────────────────
  const adminSignIn = async (username, password) => {
    const { data } = await adminLogin(username, password);
    localStorage.setItem("fh_admin_token", data.token);
    localStorage.setItem("fh_admin_user", JSON.stringify({
      username:    data.username,
      role:        data.role,
      displayName: data.displayName,
    }));
    setAdminUser({ username: data.username, role: data.role, displayName: data.displayName });
    return data;
  };

  const adminSignOut = async () => {
    // 1. Tell the backend to blacklist the token (ignore failures — token might already be expired)
    try { await adminLogout(); } catch (_) { /* intentionally swallowed */ }

    // 2. Always clear local storage and React state regardless of server response
    localStorage.removeItem("fh_admin_token");
    localStorage.removeItem("fh_admin_user");
    setAdminUser(null);

    // Return resolved so callers can await and then navigate
  };

  // ── Customer ───────────────────────────────────────────────────────────────
  const customerSignIn = async (email, password) => {
    const { data } = await customerLogin({ email, password });
    localStorage.setItem("fh_customer_token", data.token);
    localStorage.setItem("fh_customer", JSON.stringify({
      id: data.id, name: data.name, email: data.email, phone: data.phone,
    }));
    setCustomer({ id: data.id, name: data.name, email: data.email, phone: data.phone });
    return data;
  };

  const customerRegisterFn = async (form) => {
    const { data } = await customerRegister(form);
    localStorage.setItem("fh_customer_token", data.token);
    localStorage.setItem("fh_customer", JSON.stringify({
      id: data.id, name: data.name, email: data.email, phone: data.phone,
    }));
    setCustomer({ id: data.id, name: data.name, email: data.email, phone: data.phone });
    return data;
  };

  const customerSignOut = async () => {
    try { await customerLogout(); } catch (_) { /* intentionally swallowed */ }
    localStorage.removeItem("fh_customer_token");
    localStorage.removeItem("fh_customer");
    setCustomer(null);
  };

  const isSuperAdmin = adminUser?.role === "SUPERADMIN";
  const isStaff      = adminUser?.role === "STAFF";

  return (
    <AuthContext.Provider value={{
      adminUser, adminSignIn, adminSignOut, isAdmin: !!adminUser, isSuperAdmin, isStaff,
      customer, customerSignIn, customerRegisterFn, customerSignOut, isCustomer: !!customer,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

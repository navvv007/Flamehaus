import { useState, useEffect } from "react";
import { getAdminRatings } from "../../api/apiClient";
import { Link } from "react-router-dom";

function Stars({ n }) {
  return (
    <span style={{ color: "#F4C842", fontSize: "0.95rem" }}>
      {"★".repeat(n)}
      <span style={{ color: "#333" }}>{"★".repeat(5 - n)}</span>
    </span>
  );
}

function fmt(dt) {
  if (!dt) return "—";
  return new Date(dt).toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function AdminRatings() {
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter,  setFilter]  = useState(0); // 0 = all

  useEffect(() => {
    getAdminRatings()
      .then((r) => setRatings(r.data))
      .finally(() => setLoading(false));
  }, []);

  const filtered = filter === 0 ? ratings : ratings.filter((r) => r.stars === filter);
  const avg = ratings.length ? (ratings.reduce((s, r) => s + r.stars, 0) / ratings.length).toFixed(1) : "—";
  const dist = [5, 4, 3, 2, 1].map((s) => ({ stars: s, count: ratings.filter((r) => r.stars === s).length }));

  return (
    <div style={{ padding: "40px 36px" }}>
      <div style={{ marginBottom: 36 }}>
        <div className="section-label">Ratings Overview</div>
        <h1 style={{ fontSize: "2rem" }}>Customer Ratings</h1>
        <p style={{ color: "var(--muted)", fontSize: "0.9rem", marginTop: 4 }}>{ratings.length} total reviews</p>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "200px 1fr", gap: 24, marginBottom: 36 }}>
        <div className="card" style={{ padding: "28px 24px", textAlign: "center" }}>
          <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "3.5rem", color: "var(--flame)", lineHeight: 1 }}>{avg}</div>
          <Stars n={Math.round(parseFloat(avg) || 0)} />
          <p style={{ color: "var(--muted)", fontSize: "0.82rem", marginTop: 8 }}>{ratings.length} reviews</p>
        </div>
        <div className="card" style={{ padding: "24px 28px" }}>
          <p style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, marginBottom: 16 }}>Distribution</p>
          {dist.map(({ stars, count }) => {
            const pct = ratings.length ? Math.round((count / ratings.length) * 100) : 0;
            return (
              <div key={stars} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10, cursor: "pointer" }}
                onClick={() => setFilter(filter === stars ? 0 : stars)}>
                <span style={{ fontSize: "0.85rem", minWidth: 20, color: filter === stars ? "var(--flame)" : "var(--white)" }}>{stars}★</span>
                <div style={{ flex: 1, height: 8, background: "var(--border)", borderRadius: 4, overflow: "hidden" }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: filter === stars ? "var(--flame)" : "#F4C842", borderRadius: 4, transition: "width 0.4s" }} />
                </div>
                <span style={{ fontSize: "0.8rem", color: "var(--muted)", minWidth: 36, textAlign: "right" }}>{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filter pills */}
      <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
        {[["All", 0], ["5★", 5], ["4★", 4], ["3★", 3], ["2★", 2], ["1★", 1]].map(([lbl, val]) => (
          <button key={val} onClick={() => setFilter(val)} style={{
            padding: "7px 18px", borderRadius: 50, fontWeight: 600, fontSize: "0.82rem",
            background: filter === val ? "var(--flame)" : "var(--card)",
            color:      filter === val ? "#fff" : "var(--muted)",
            border:     `1.5px solid ${filter === val ? "var(--flame)" : "var(--border)"}`,
            transition: "all 0.2s",
          }}>{lbl}</button>
        ))}
      </div>

      {/* Ratings list */}
      {loading ? (
        <div style={{ textAlign: "center", padding: 60, color: "var(--muted)" }}>Loading…</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: 60, color: "var(--muted)" }}>
          <div style={{ fontSize: "2.5rem", marginBottom: 12 }}>⭐</div>
          <p>No ratings yet</p>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 18 }}>
          {filtered.map((r) => (
            <div key={r.id} className="card" style={{ padding: "22px 24px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                <div>
                  <Stars n={r.stars} />
                  <p style={{ color: "var(--muted)", fontSize: "0.78rem", marginTop: 4 }}>{fmt(r.createdAt)}</p>
                </div>
                <Link to={`/admin/orders/${r.order?.id}`} style={{
                  fontSize: "0.78rem", color: "var(--flame)", fontWeight: 600,
                  padding: "4px 10px", border: "1px solid rgba(255,107,53,0.3)",
                  borderRadius: 20, background: "rgba(255,107,53,0.08)"
                }}>
                  #{r.order?.id}
                </Link>
              </div>
              {r.comment && (
                <p style={{ color: "var(--white)", fontSize: "0.87rem", lineHeight: 1.6, marginBottom: 10 }}>
                  "{r.comment}"
                </p>
              )}
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--flame)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.85rem" }}>
                  {r.customer?.name?.[0]?.toUpperCase() || "G"}
                </div>
                <div>
                  <p style={{ fontSize: "0.83rem", fontWeight: 600 }}>{r.customer?.name || "Guest"}</p>
                  <p style={{ fontSize: "0.75rem", color: "var(--muted)" }}>{r.customer?.email || "—"}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

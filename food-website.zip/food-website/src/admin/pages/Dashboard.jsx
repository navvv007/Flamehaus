import { useEffect, useState } from "react";
import { fetchDashboard, fetchAdminOrders } from "../../api/apiClient";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from "recharts";

const StatusBadge = ({ status }) => {
  const colors = {
    Delivered:    { bg: "rgba(87,204,153,0.15)",  color: "#57CC99" },
    Preparing:    { bg: "rgba(244,200,66,0.15)",  color: "#F4C842" },
    "On the Way": { bg: "rgba(76,201,240,0.15)",  color: "#4CC9F0" },
    Pending:      { bg: "rgba(255,107,53,0.15)",  color: "#FF6B35" },
  };
  const s = colors[status] || { bg: "#222", color: "#888" };
  return (
    <span style={{ background: s.bg, color: s.color, padding: "4px 12px", borderRadius: 20, fontSize: "0.75rem", fontWeight: 600 }}>
      {status}
    </span>
  );
};

const staticSales = [
  { month: "Jan", revenue: 42000, orders: 320 },
  { month: "Feb", revenue: 38000, orders: 295 },
  { month: "Mar", revenue: 51000, orders: 410 },
  { month: "Apr", revenue: 47000, orders: 375 },
  { month: "May", revenue: 62000, orders: 495 },
  { month: "Jun", revenue: 58000, orders: 460 },
];

export default function Dashboard() {
  const [stats, setStats]   = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState("");

  useEffect(() => {
    Promise.all([fetchDashboard(), fetchAdminOrders()])
      .then(([statsRes, ordersRes]) => {
        setStats(statsRes.data);
        setOrders(ordersRes.data.slice(0, 5));
      })
      .catch(() => setError("Failed to load dashboard data"))
      .finally(() => setLoading(false));
  }, []);

  const customTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 10, padding: "10px 16px", fontSize: "0.85rem" }}>
        <p style={{ fontWeight: 600, marginBottom: 4 }}>{label}</p>
        {payload.map((p) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: {p.name === "revenue" ? `₹${p.value.toLocaleString()}` : p.value}
          </p>
        ))}
      </div>
    );
  };

  if (loading) return (
    <div style={{ padding: "40px 36px" }}>
      <div style={{ color: "var(--muted)", marginTop: 80, textAlign: "center", fontSize: "1rem" }}>Loading dashboard…</div>
    </div>
  );

  const statCards = stats ? [
    { label: "Total Revenue",   value: `₹${(stats.totalRevenue * 84).toLocaleString()}`, icon: "💰", change: "+12%",        up: true  },
    { label: "Total Orders",    value: stats.totalOrders,                                 icon: "📦", change: "All time",     up: true  },
    { label: "Menu Items",      value: stats.menuItems,                                   icon: "🍽", change: "Active",       up: true  },
    { label: "Pending Orders",  value: stats.pendingOrders,                               icon: "⏳", change: "Need action",  up: false },
  ] : [];

  return (
    <div style={{ padding: "40px 36px" }}>
      <div style={{ marginBottom: 36 }}>
        <div className="section-label">Admin Dashboard</div>
        <h1 style={{ fontSize: "2rem" }}>Overview</h1>
        {error && <p style={{ color: "#E63946", marginTop: 8, fontSize: "0.88rem" }}>{error}</p>}
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20, marginBottom: 36 }}>
        {statCards.map((s) => (
          <div key={s.label} className="card" style={{ padding: "24px 22px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: 14 }}>
              <span style={{ fontSize: "1.6rem" }}>{s.icon}</span>
              <span style={{ fontSize: "0.75rem", fontWeight: 600, color: s.up ? "var(--green)" : "#FF6B35" }}>{s.change}</span>
            </div>
            <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.8rem", marginBottom: 4 }}>{s.value}</div>
            <div style={{ color: "var(--muted)", fontSize: "0.82rem" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 36 }}>
        <div className="card" style={{ padding: 24 }}>
          <h3 style={{ fontFamily: "Syne, sans-serif", marginBottom: 20 }}>Monthly Revenue</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={staticSales}>
              <XAxis dataKey="month" stroke="#555" tick={{ fill: "#888", fontSize: 12 }} />
              <YAxis stroke="#555" tick={{ fill: "#888", fontSize: 12 }} />
              <Tooltip content={customTooltip} />
              <Bar dataKey="revenue" fill="#FF6B35" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card" style={{ padding: 24 }}>
          <h3 style={{ fontFamily: "Syne, sans-serif", marginBottom: 20 }}>Monthly Orders</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={staticSales}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
              <XAxis dataKey="month" stroke="#555" tick={{ fill: "#888", fontSize: 12 }} />
              <YAxis stroke="#555" tick={{ fill: "#888", fontSize: 12 }} />
              <Tooltip content={customTooltip} />
              <Line type="monotone" dataKey="orders" stroke="#57CC99" strokeWidth={2.5} dot={{ fill: "#57CC99", r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="card" style={{ padding: 24 }}>
        <h3 style={{ fontFamily: "Syne, sans-serif", marginBottom: 20 }}>Recent Orders</h3>
        {orders.length === 0 ? (
          <p style={{ color: "var(--muted)", textAlign: "center", padding: "40px 0" }}>No orders yet</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)" }}>
                {["ID", "Customer", "Items", "Total", "Status", "Time"].map((h) => (
                  <th key={h} style={{ textAlign: "left", padding: "8px 12px", color: "var(--muted)", fontWeight: 600, fontSize: "0.8rem" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} style={{ borderBottom: "1px solid var(--border)" }}
                  onMouseEnter={(e) => { e.currentTarget.style.background = "var(--charcoal)"; }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}>
                  <td style={{ padding: "14px 12px", fontWeight: 600, color: "var(--flame)", fontSize: "0.88rem" }}>#{o.id}</td>
                  <td style={{ padding: "14px 12px", fontSize: "0.88rem" }}>{o.customerName}</td>
                  <td style={{ padding: "14px 12px", color: "var(--muted)", fontSize: "0.82rem", maxWidth: 200 }}>
                    {o.itemsSummary ? o.itemsSummary.substring(0, 50) + (o.itemsSummary.length > 50 ? "…" : "") : "—"}
                  </td>
                  <td style={{ padding: "14px 12px", fontWeight: 600 }}>₹{(o.total * 84).toFixed(0)}</td>
                  <td style={{ padding: "14px 12px" }}><StatusBadge status={o.status} /></td>
                  <td style={{ padding: "14px 12px", color: "var(--muted)", fontSize: "0.82rem" }}>
                    {new Date(o.createdAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { fetchAdminOrders, advanceOrder } from "../../api/apiClient";

const statuses = ["All", "Pending", "Preparing", "On the Way", "Delivered"];

const statusColors = {
  Delivered:    { bg: "rgba(87,204,153,0.15)",  color: "#57CC99",  border: "rgba(87,204,153,0.3)" },
  Preparing:    { bg: "rgba(244,200,66,0.15)",  color: "#F4C842",  border: "rgba(244,200,66,0.3)" },
  "On the Way": { bg: "rgba(76,201,240,0.15)",  color: "#4CC9F0",  border: "rgba(76,201,240,0.3)" },
  Pending:      { bg: "rgba(255,107,53,0.15)",  color: "#FF6B35",  border: "rgba(255,107,53,0.3)" },
};

const nextStatus = { Pending: "Preparing", Preparing: "On the Way", "On the Way": "Delivered" };

export default function AdminOrders() {
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter]   = useState("All");
  const [search, setSearch]   = useState("");
  const [error, setError]     = useState("");

  const load = useCallback(() => {
    setLoading(true);
    fetchAdminOrders()
      .then((r) => setOrders(r.data))
      .catch(() => setError("Failed to load orders"))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = orders
    .filter((o) => filter === "All" || o.status === filter)
    .filter((o) => o.customerName?.toLowerCase().includes(search.toLowerCase()) || String(o.id).includes(search));

  const handleAdvance = async (id) => {
    try {
      const res = await advanceOrder(id);
      setOrders((prev) => prev.map((o) => o.id === id ? res.data : o));
    } catch (e) {
      setError(e.response?.data?.error || "Failed to advance order");
    }
  };

  const counts = statuses.slice(1).reduce((acc, s) => ({ ...acc, [s]: orders.filter((o) => o.status === s).length }), {});

  return (
    <div style={{ padding: "40px 36px" }}>
      <div style={{ marginBottom: 36 }}>
        <div className="section-label">Order Management</div>
        <h1 style={{ fontSize: "2rem" }}>Orders</h1>
        <p style={{ color: "var(--muted)", fontSize: "0.9rem", marginTop: 4 }}>{orders.length} total orders</p>
        {error && <p style={{ color: "#E63946", fontSize: "0.88rem", marginTop: 6 }}>{error}</p>}
      </div>

      {/* Summary cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 32 }}>
        {Object.entries(counts).map(([status, count]) => {
          const s = statusColors[status];
          return (
            <div key={status} className="card" style={{ padding: "18px 20px", cursor: "pointer", transition: "all 0.2s" }}
              onClick={() => setFilter(status)}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = s.border; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--border)"; }}>
              <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.8rem", color: s.color, marginBottom: 4 }}>{count}</div>
              <div style={{ color: "var(--muted)", fontSize: "0.82rem" }}>{status}</div>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
        <input type="text" placeholder="🔍 Search by customer or order ID..." value={search} onChange={(e) => setSearch(e.target.value)} style={{ flex: 1, minWidth: 220 }} />
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {statuses.map((s) => (
            <button key={s} onClick={() => setFilter(s)} style={{
              padding: "9px 16px", borderRadius: 50, fontWeight: 600, fontSize: "0.82rem",
              background: filter === s ? "var(--flame)" : "var(--card)",
              color: filter === s ? "#fff" : "var(--muted)",
              border: `1.5px solid ${filter === s ? "var(--flame)" : "var(--border)"}`,
              transition: "all 0.2s"
            }}>{s}</button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="card" style={{ overflow: "hidden" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 60, color: "var(--muted)" }}>Loading orders…</div>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "var(--charcoal)", borderBottom: "1px solid var(--border)" }}>
                {["Order ID", "Customer", "Items", "Total", "Date & Time", "Status", "Action"].map((h) => (
                  <th key={h} style={{ textAlign: "left", padding: "14px 16px", color: "var(--muted)", fontWeight: 600, fontSize: "0.8rem", letterSpacing: 0.5 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => {
                const s = statusColors[o.status] || { bg: "#222", color: "#888", border: "#333" };
                const can = !!nextStatus[o.status];
                return (
                  <tr key={o.id} style={{ borderBottom: "1px solid var(--border)" }}
                    onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,107,53,0.03)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}>
                    <td style={{ padding: "14px 16px", fontWeight: 700, color: "var(--flame)", fontSize: "0.88rem" }}>#{o.id}</td>
                    <td style={{ padding: "14px 16px", fontWeight: 600, fontSize: "0.88rem" }}>{o.customerName}</td>
                    <td style={{ padding: "14px 16px", color: "var(--muted)", fontSize: "0.8rem", maxWidth: 180 }}>
                      {o.itemsSummary ? o.itemsSummary.substring(0, 50) + (o.itemsSummary.length > 50 ? "…" : "") : "—"}
                    </td>
                    <td style={{ padding: "14px 16px", fontWeight: 700 }}>₹{(o.total * 84).toFixed(0)}</td>
                    <td style={{ padding: "14px 16px", color: "var(--muted)", fontSize: "0.82rem" }}>
                      {new Date(o.createdAt).toLocaleDateString("en-IN")}<br />
                      <span style={{ color: "var(--white)", fontSize: "0.78rem" }}>
                        {new Date(o.createdAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </td>
                    <td style={{ padding: "14px 16px" }}>
                      <span style={{ padding: "5px 12px", borderRadius: 20, fontSize: "0.75rem", fontWeight: 600, background: s.bg, color: s.color, border: `1px solid ${s.border}` }}>{o.status}</span>
                    </td>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <Link to={`/admin/orders/${o.id}`} style={{
                          padding: "7px 14px", borderRadius: 8, fontSize: "0.78rem", fontWeight: 600,
                          background: "var(--charcoal)", color: "var(--muted)",
                          border: "1px solid var(--border)", whiteSpace: "nowrap",
                        }}>
                          View →
                        </Link>
                        {can && (
                          <button onClick={() => handleAdvance(o.id)} style={{
                            padding: "7px 14px", borderRadius: 8, fontSize: "0.78rem", fontWeight: 600,
                            background: "rgba(255,107,53,0.15)", color: "var(--flame)",
                            border: "1px solid rgba(255,107,53,0.3)", whiteSpace: "nowrap", transition: "all 0.2s"
                          }}
                            onMouseEnter={(e) => { e.currentTarget.style.background = "var(--flame)"; e.currentTarget.style.color = "#fff"; }}
                            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(255,107,53,0.15)"; e.currentTarget.style.color = "var(--flame)"; }}>
                            → {nextStatus[o.status]}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
        {!loading && filtered.length === 0 && (
          <div style={{ textAlign: "center", padding: 60, color: "var(--muted)" }}>
            <div style={{ fontSize: "2.5rem", marginBottom: 12 }}>📦</div>
            <p>No orders found</p>
          </div>
        )}
      </div>
    </div>
  );
}
